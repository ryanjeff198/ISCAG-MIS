<?php
$name_parts = explode(' ', trim($_SESSION['name'] ?? 'User'));
$first_initial = substr($name_parts[0], 0, 1);
$last_initial = count($name_parts) > 1 ? substr(end($name_parts), 0, 1) : '';
$initials = strtoupper($first_initial . $last_initial);

$active_page = $active_page ?? 'dashboard';

$userUnreadCount = 0;
if (!empty($_SESSION['user_id'])) {
    try {
        require_once BASE_PATH . '/app/models/Notification.php';
        $userUnreadCount = (new Notification())->getUnreadCount((int)$_SESSION['user_id']);
    } catch (\Exception $e) {}
}
?>
<aside class="sidebar" id="sidebar" style="font-family:'Source Sans 3',sans-serif; font-size:14.5px;">
    <button class="sidebar-toggle" id="sidebar-toggle" title="Toggle sidebar">
        <svg viewBox="0 0 24 24">
            <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" />
        </svg>
    </button>
    <div class="sidebar-header">
        <div class="sidebar-brand">
            <img src="<?= asset('assets/logo.jpg') ?>" style="max-width:48px;max-height:48px;border-radius:8px;" alt="ISCAG" />
            <div class="brand-text"><strong>ISCAG MIS</strong><span>User Portal</span></div>
        </div>
    </div>
    <div class="sidebar-user">
        <div class="user-avatar" id="nav-avatar" style="background:var(--accent); overflow:hidden;">
            <?php 
                $avatar_url = url('/user/profile/avatar/serve'); 
                // We show the image. If serveAvatar returns 404, it might look broken unless we add JS fallback, 
                // but at least it tries to show the real one now.
            ?>
            <img src="<?= $avatar_url ?>?t=<?= time() ?>" 
                 style="width:100%; height:100%; object-fit:cover; display:block;" 
                 onerror="this.style.display='none'; this.parentElement.innerHTML='<?= $initials ?>';"
                 alt="Profile" />
        </div>
        <div class="user-info">
            <strong id="nav-name" data-preserve="true" data-force-sync="true"><?= htmlspecialchars($_SESSION['name'] ?? 'User') ?></strong>
            <span id="nav-role" data-preserve="true"><?= htmlspecialchars($_SESSION['role'] ?? 'Verified User') ?></span>
        </div>
    </div>
    <nav class="sidebar-nav">
        <div class="nav-section-label">Menu</div>
        <a href="<?= url('/user/dashboard') ?>" class="nav-item <?= $active_page === 'dashboard' ? 'active' : '' ?>" data-tooltip="Dashboard">
            <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z" />
            </svg>
            <span class="nav-item-label">My Dashboard</span>
        </a>
        <a href="<?= url('/user/profile') ?>" class="nav-item <?= $active_page === 'profile' ? 'active' : '' ?>" data-tooltip="Profile">
            <svg viewBox="0 0 24 24" fill="currentColor">
                <path
                    d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z" />
            </svg>
            <span class="nav-item-label">My Profile</span>
        </a>
        <a href="<?= url('/user/notifications') ?>" class="nav-item <?= $active_page === 'notifications' ? 'active' : '' ?>" data-tooltip="Notifications" style="position:relative;">
            <svg viewBox="0 0 24 24" fill="currentColor">
                <path
                    d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" />
            </svg>
            <span class="nav-item-label">Notifications</span>
            <span class="notif-dot" id="user-notif-dot" style="<?= $userUnreadCount > 0 ? '' : 'display:none;' ?>"><?= $userUnreadCount > 99 ? '99+' : $userUnreadCount ?></span>
        </a>
        <div class="nav-section-label">Services</div>

        <!-- DAMAYAN DROPDOWN -->
        <?php $damayan_active = in_array($active_page, ['burial', 'burial_service', 'burial_dashboard', 'burial_tracking', 'charity']); ?>
        <div class="nav-dropdown-wrap <?= $damayan_active ? 'open' : '' ?>" id="damayan-wrap">
            <button class="nav-dropdown-trigger <?= $damayan_active ? 'open' : '' ?>" id="damayan-trigger" data-tooltip="Damayan">
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" />
                </svg>
                <span class="nav-item-label">Damayan</span>
                <svg class="nav-dropdown-arrow" viewBox="0 0 24 24">
                    <path d="M7 10l5 5 5-5z" />
                </svg>
            </button>
            <div class="nav-dropdown <?= $damayan_active ? 'open' : '' ?>" id="damayan-menu">
                <a href="<?= url('/user/services/burial-dashboard') ?>" class="<?= in_array($active_page, ['burial', 'burial_dashboard', 'burial_tracking']) ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
                    </svg>
                    Damayan Dashboard
                </a>
                <a href="<?= url('/user/services/burial-details?action=request') ?>" class="<?= $active_page === 'burial_service' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path
                            d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                    </svg>
                    Submit Request
                </a>
                <a href="<?= url('/user/services/charity') ?>" class="<?= $active_page === 'charity' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                    </svg>
                    Charity / Donation
                </a>
            </div>
        </div>

        <!-- DA'WAH DROPDOWN -->
        <?php $dawah_active = in_array($active_page, ['counseling_male', 'counseling_female']); ?>
        <div class="nav-dropdown-wrap <?= $dawah_active ? 'open' : '' ?>" id="dawah-wrap">
            <button class="nav-dropdown-trigger <?= $dawah_active ? 'open' : '' ?>" id="dawah-trigger" data-tooltip="Da'wah">
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z" />
                </svg>
                <span class="nav-item-label">Da'wah</span>
                <svg class="nav-dropdown-arrow" viewBox="0 0 24 24">
                    <path d="M7 10l5 5 5-5z" />
                </svg>
            </button>
            <div class="nav-dropdown <?= $dawah_active ? 'open' : '' ?>" id="dawah-menu">
                <?php 
                $sex = strtolower($_SESSION['sex'] ?? $_SESSION['gender'] ?? '');
                if ($sex !== 'female'): ?>
                <a href="<?= url('/user/services/counseling/male') ?>" class="<?= $active_page === 'counseling_male' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/></svg>
                    Counseling & Guidance
                </a>
                <?php endif; ?>
                <?php if ($sex !== 'male'): ?>
                <a href="<?= url('/user/services/counseling/female') ?>" class="<?= $active_page === 'counseling_female' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/></svg>
                    Counseling Service
                </a>
                
                <?php 
                $isEnrolled = !empty($_SESSION['female_education_enrolled']);
                $isFemale = (strtolower($_SESSION['sex'] ?? $_SESSION['gender'] ?? '') === 'female');
                ?>
                
                <?php if ($isFemale): ?>
                <a href="<?= url('/user/services/education/female/school') ?>" class="<?= $active_page === 'female_school' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.1 0-2 .9-2 2v14a2 2 0 002 2h14a2 2 0 002-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z"/></svg>
                    School Schedule
                </a>

                <a href="<?= url('/user/services/education/female#my-registrations-card') ?>" class="<?= in_array($active_page, ['enrolled_courses', 'female_enrolled_courses']) ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm16-4H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H8V4h12v12z"/></svg>
                    Enrolled Courses
                </a>
                
                <?php if (!$isEnrolled): ?>
                <a href="<?= url('/user/services/education/female') ?>" class="<?= $active_page === 'female_education' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3L1 9l11 6 9-4.91V17h2V9L12 3zM5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82z"/></svg>
                    Registration Form
                </a>
                <?php else: ?>
                <a href="<?= url('/user/services/education/female/subjects') ?>" class="<?= $active_page === 'female_subjects' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3L1 9l11 6 9-4.91V17h2V9L12 3zM5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82z"/></svg>
                    My Learning
                </a>
                <?php endif; ?>
                <?php endif; ?>
                <?php endif; ?>

                <?php if ($sex !== 'female'): ?>
                <a href="<?= url('/user/services/marriage-form') ?>" class="<?= $active_page === 'marriage_form' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                    Marriage Services
                </a>
                <a href="<?= url('/user/services/conversion-form') ?>" class="<?= $active_page === 'conversion_form' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3L1 9l11 6 9-4.91V17h2V9L12 3zM5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82z"/></svg>
                    Islamic Studies
                </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- APARTMENT DROPDOWN -->
        <?php $apartment_active = in_array($active_page, ['apartment_apply', 'apartment_status', 'apartment_info', 'apartment_parking', 'apartment_lease', 'apartment_payment', 'apartment_soa']); ?>
        <div class="nav-dropdown-wrap <?= $apartment_active ? 'open' : '' ?>" id="apartment-wrap">
            <button class="nav-dropdown-trigger <?= $apartment_active ? 'open' : '' ?>" id="apartment-trigger" data-tooltip="Apartment">
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17 11V3H7v4H3v14h8v-4h2v4h8V11h-4z" />
                </svg>
                <span class="nav-item-label">Apartment</span>
                <svg class="nav-dropdown-arrow" viewBox="0 0 24 24">
                    <path d="M7 10l5 5 5-5z" />
                </svg>
            </button>
            <div class="nav-dropdown <?= $apartment_active ? 'open' : '' ?>" id="apartment-menu">
                <?php if (($_SESSION['role'] ?? '') === 'Guest'): ?>
                <a href="<?= url('/user/apartment/apply') ?>" class="<?= $active_page === 'apartment_apply' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path
                            d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-1 7V3.5L18.5 9H13z" />
                    </svg>
                    Application Form
                </a>
                <a href="<?= url('/user/apartment/status') ?>" class="<?= $active_page === 'apartment_status' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path
                            d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z" />
                    </svg>
                    Application Status
                </a>
                <?php endif; ?>
                <?php if (in_array($_SESSION['role'] ?? '', ['Guest', 'Tenant'])): ?>
                <a href="<?= url('/user/apartment/lease') ?>" class="<?= $active_page === 'apartment_lease' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.89 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z" />
                    </svg>
                    Lease Contract
                </a>
                <a href="<?= url('/user/apartment/payment') ?>" class="<?= $active_page === 'apartment_payment' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/>
                    </svg>
                    Bills & Payments
                </a>
                <?php endif; ?>
                
                <?php if (($_SESSION['role'] ?? '') === 'Tenant'): ?>
                <a href="<?= url('/user/apartment/soa') ?>" class="<?= $active_page === 'apartment_soa' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM7 10h2v2H7zm0 4h2v2H7zm4-4h6v2h-6zm0 4h6v2h-6z" />
                    </svg>
                    Statement of Account
                </a>
                <a href="<?= url('/user/apartment/info') ?>" class="<?= $active_page === 'apartment_info' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M14 17H4v2h10v-2zm6-8H4v2h16V9zM4 15h16v-2H4v2zM4 5v2h16V5H4z" />
                    </svg>
                    Apartment Information
                </a>
                <a href="<?= url('/user/apartment/parking') ?>" class="<?= $active_page === 'apartment_parking' ? 'active-submenu' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z" />
                    </svg>
                    Parking Rental
                </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <div class="sidebar-footer">
        <a href="<?= url('/logout') ?>" class="nav-item" data-tooltip="Logout">
            <svg viewBox="0 0 24 24" fill="currentColor">
                <path
                    d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z" />
            </svg>
            <span class="nav-item-label">Logout</span>
        </a>
    </div>

    <!-- ═══ APPROVAL MODAL ═══ -->
    <style>
        #approval-modal {
            position: fixed; inset: 0; z-index: 99999;
            display: none; align-items: center; justify-content: center;
            background: rgba(15,30,22,0.6); backdrop-filter: blur(6px);
            opacity: 0; transition: opacity 0.3s ease;
        }
        #approval-modal.show {
            display: flex; opacity: 1;
        }
        .approval-modal-content {
            background: white; border-radius: 16px; width: 100%; max-width: 440px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.25); overflow: hidden;
            position: relative;
            transform: translateY(30px); transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        #approval-modal.show .approval-modal-content {
            transform: translateY(0);
        }
        .approval-modal-close {
            position: absolute; top: 12px; right: 14px;
            background: none; border: none; font-size: 24px; line-height: 1;
            color: #6f7f78; cursor: pointer; padding: 4px 8px; border-radius: 6px;
            transition: all 0.15s; z-index: 2;
        }
        .approval-modal-close:hover { color: #1f2e2a; background: rgba(0,0,0,0.05); }
        .approval-modal-header { height: 4px; background: linear-gradient(90deg,#0f5c3a,#c79a2b); }
        .approval-modal-body { padding: 32px 28px 24px; text-align: center; }
        .approval-modal-icon { width: 64px; height: 64px; fill: #2f8a60; margin: 0 auto 16px; }
        .approval-modal-title { font-family: 'Lora', serif; font-size: 1.4rem; font-weight: 700; color: #0f5c3a; margin: 0 0 10px; }
        .approval-modal-text { font-size: 0.9rem; color: #6f7f78; line-height: 1.6; margin: 0; }
        .approval-modal-footer { display: flex; gap: 10px; padding: 0 28px 24px; justify-content: center; }
        .approval-btn {
            padding: 10px 24px; border-radius: 8px; border: none;
            background: linear-gradient(135deg,#0f5c3a,#2f8a60);
            color: white; font-size: 0.9rem; font-weight: 700; cursor: pointer;
            box-shadow: 0 4px 12px rgba(15,92,58,0.3); transition: all 0.2s;
        }
        .approval-btn:hover { transform: translateY(-2px); box-shadow: 0 6px 16px rgba(15,92,58,0.4); }
    </style>
    <div id="approval-modal">
        <div class="approval-modal-content">
            <button type="button" class="approval-modal-close" id="approval-close-btn" title="Close modal">&times;</button>
            <div class="approval-modal-header"></div>
            <div class="approval-modal-body">
                <svg class="approval-modal-icon" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
                <h4 class="approval-modal-title">Congratulations!</h4>
                <p class="approval-modal-text" id="approval-modal-desc">You are now officially a tenant. Your application has been approved, your room has been assigned, and all tenant features are now unlocked.</p>
            </div>
            <div class="approval-modal-footer">
                <button class="approval-btn" id="approval-continue-btn">Continue to Dashboard</button>
            </div>
        </div>
    </div>

    <!-- ═══ LOGOUT CONFIRMATION MODAL ═══ -->
    <div id="logout-confirm-modal" style="position:fixed;inset:0;background:rgba(15,30,22,0.6);backdrop-filter:blur(6px);z-index:99999;display:none;align-items:center;justify-content:center;opacity:0;transition:opacity 0.2s;">
        <div style="background:white;border-radius:16px;width:100%;max-width:400px;box-shadow:0 20px 60px rgba(0,0,0,0.25);overflow:hidden;transform:translateY(20px);transition:transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);">
            <div style="height:4px;background:linear-gradient(90deg,#8b2e2e,#c79a2b);"></div>
            <div style="padding:40px 28px 32px;text-align:center;">
                <h4 style="font-family:'Lora',serif;font-size:1.25rem;font-weight:700;color:#1f2e2a;margin:0;">Log out of your account?</h4>
            </div>
            <div style="display:flex;gap:12px;padding:0 28px 32px;justify-content:center;">
                <button id="logout-cancel-btn" style="flex:1;padding:12px 0;border-radius:10px;border:1.5px solid #e8ece9;background:white;color:#6f7f78;font-weight:600;cursor:pointer;transition:all 0.2s;font-family:inherit;">Cancel</button>
                <button id="logout-confirm-btn" style="flex:1;padding:12px 0;border-radius:10px;border:none;background:#8b2e2e;color:white;font-weight:700;cursor:pointer;transition:all 0.2s;font-family:inherit;box-shadow:0 4px 12px rgba(139,46,46,0.25);">Yes, Logout</button>
            </div>
        </div>
    </div>
</aside>
<script>
    /**
     * ISCAG MIS — Sidebar & Shared Portal Logic
     * Handles: Toggles, Dropdowns, State Sync, and Real-time Polling
     */
    (function() {
        // ── 1. SESSION TO LOCALSTORAGE SYNC ──
        const sessionUser = {
            id: '<?= $_SESSION['user_id'] ?? "USR-001" ?>',
            name: '<?= addslashes($_SESSION['name'] ?? "User") ?>',
            role: '<?= addslashes($_SESSION['role'] ?? "Guest") ?>',
            sex: '<?= addslashes($_SESSION['sex'] ?? $_SESSION['gender'] ?? "") ?>'
        };
        const raw = localStorage.getItem('mis_user');
        let stored = raw ? JSON.parse(raw) : {};
        
        // Detection: If user ID changed, reset relevant localStorage to avoid data leakage
        if (stored.id && stored.id !== sessionUser.id) {
            console.log('User change detected. Clearing stale data.');
            stored = {};
            localStorage.removeItem('mis_user_photo');
            localStorage.removeItem('mis_member_since');
            localStorage.removeItem('mis_last_login');
        }

        // Always prioritize and overwrite with session values
        Object.assign(stored, sessionUser);
        
        localStorage.setItem('mis_user', JSON.stringify(stored));

        // ── 2. SIDEBAR TOGGLE & DROPDOWNS ──
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebar-toggle');
        if (sidebar && sidebarToggle) {
            sidebarToggle.addEventListener('click', () => sidebar.classList.toggle('collapsed'));
        }

        function initDropdown(triggerId, menuId, wrapId) {
            const trigger = document.getElementById(triggerId);
            const menu = document.getElementById(menuId);
            const wrap = document.getElementById(wrapId);
            if (!trigger || !menu) return;

            trigger.addEventListener('click', (e) => {
                e.preventDefault();
                const isOpen = menu.classList.contains('open');
                document.querySelectorAll('.nav-dropdown, .nav-dropdown-trigger, .nav-dropdown-wrap').forEach(el => el.classList.remove('open'));
                if (!isOpen) {
                    menu.classList.add('open');
                    trigger.classList.add('open');
                    if (wrap) wrap.classList.add('open');
                }
            });
        }

        // ── Apply Locks based on Profile Status ──
        function applySidebarLocks() {
            const stored = JSON.parse(localStorage.getItem('mis_user') || '{}');
            const isComplete = stored.profileComplete || false;
            const isTenant = stored.role === 'Tenant';
            const wraps = ['apartment-wrap'];
            
            wraps.forEach(id => {
                const wrap = document.getElementById(id);
                if (wrap) {
                    if (isComplete || isTenant) wrap.classList.remove('locked');
                    else wrap.classList.add('locked');
                }
            });
        }

        initDropdown('damayan-trigger', 'damayan-menu', 'damayan-wrap');
        initDropdown('dawah-trigger', 'dawah-menu', 'dawah-wrap');
        initDropdown('apartment-trigger', 'apartment-menu', 'apartment-wrap');

        // ── 2b. Da'wah Trigger data-href Sync ──
        const dawahTrigger = document.getElementById('dawah-trigger');
        if (dawahTrigger) {
            const sex = '<?= strtolower($_SESSION['sex'] ?? $_SESSION['gender'] ?? "") ?>';
            const dawahHref = (sex === 'female') ? "<?= url('/user/services/counseling/female') ?>" : "<?= url('/user/services/counseling/male') ?>";
            dawahTrigger.setAttribute('data-href', dawahHref);
        }
        
        applySidebarLocks();
        // Re-check after a short delay to ensure localStorage is ready
        setTimeout(applySidebarLocks, 500);

        // ── 3. APPROVAL POLLING & NOTIFICATIONS ──
        let approvalNotifId = null;
        function checkUserStatus() {
            fetch('<?= url("/user/status/check") ?>?t=' + Date.now())
                .then(res => res.json())
                .then(data => {
                    const notifs = data.notifications || [];
                    
                    // Update Notification Dot
                    const dot = document.querySelector('.notif-dot');
                    const unreadCount = (typeof data.unread_count !== 'undefined')
                        ? Number(data.unread_count)
                        : notifs.filter(n => n.is_read == 0).length;
                    if (dot) {
                        dot.textContent = unreadCount > 99 ? '99+' : unreadCount;
                        dot.style.display = unreadCount > 0 ? 'flex' : 'none';
                    }

                    // Check for Approval
                    const seenKey = 'mis_approval_seen_' + (sessionUser.id || 'default');
                    const isAlreadySeen = (localStorage.getItem(seenKey) === 'true' || sessionStorage.getItem(seenKey) === 'true');
                    const approvalNotif = notifs.find(n => n.type === 'approval' && n.is_read == 0);

                    if (approvalNotif && !isAlreadySeen) {
                        approvalNotifId = approvalNotif.notification_id || approvalNotif.id;
                        const desc = document.getElementById('approval-modal-desc');
                        if (desc && approvalNotif.message) {
                            desc.textContent = approvalNotif.message;
                        }
                        const modal = document.getElementById('approval-modal');
                        if (modal) {
                            modal.classList.add('show');
                        }
                    } else if (data.role === 'Tenant' && sessionUser.role === 'Guest') {
                        window.location.reload();
                    }
                })
                .catch(err => console.warn('Status check failed:', err));
        }

        function dismissApprovalModal() {
            const modal = document.getElementById('approval-modal');
            if (modal) modal.classList.remove('show');

            const seenKey = 'mis_approval_seen_' + (sessionUser.id || 'default');
            localStorage.setItem(seenKey, 'true');
            sessionStorage.setItem(seenKey, 'true');

            const stored = JSON.parse(localStorage.getItem('mis_user') || '{}');
            stored.role = 'Tenant';
            localStorage.setItem('mis_user', JSON.stringify(stored));

            const notifIdToSend = approvalNotifId;
            fetch('<?= url("/user/notifications/mark-read") ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: notifIdToSend, type: 'approval' })
            }).finally(() => {
                if (!window.location.pathname.includes('/user/dashboard')) {
                    window.location.href = '<?= url("/user/dashboard") ?>';
                }
            });
        }

        const continueBtn = document.getElementById('approval-continue-btn');
        if (continueBtn) {
            continueBtn.addEventListener('click', dismissApprovalModal);
        }

        const closeBtn = document.getElementById('approval-close-btn');
        if (closeBtn) {
            closeBtn.addEventListener('click', dismissApprovalModal);
        }

        const approvalModalOverlay = document.getElementById('approval-modal');
        if (approvalModalOverlay) {
            approvalModalOverlay.addEventListener('click', (e) => {
                if (e.target === approvalModalOverlay) dismissApprovalModal();
            });
        }

        setTimeout(checkUserStatus, 800);
        setInterval(checkUserStatus, 10000);
    })();

    // ── 4. LOGOUT MODAL ──
    function initLogoutModal() {
        const modal = document.getElementById('logout-confirm-modal');
        const cancelBtn = document.getElementById('logout-cancel-btn');
        const confirmBtn = document.getElementById('logout-confirm-btn');
        const logoutLinks = document.querySelectorAll('a[href*="/logout"], [data-tooltip="Logout"]');
        
        if (!modal || !cancelBtn || !confirmBtn) return;

        let targetHref = '';

        const showModal = (href) => {
            targetHref = href;
            modal.style.display = 'flex';
            void modal.offsetWidth; // force reflow
            modal.style.opacity = '1';
            modal.firstElementChild.style.transform = 'translateY(0)';
        };

        const hideModal = () => {
            modal.style.opacity = '0';
            modal.firstElementChild.style.transform = 'translateY(20px)';
            setTimeout(() => { modal.style.display = 'none'; }, 200);
        };

        logoutLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                showModal(link.getAttribute('href'));
            });
        });

        cancelBtn.addEventListener('click', hideModal);
        confirmBtn.addEventListener('click', () => {
            if (targetHref) window.location.href = targetHref;
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) hideModal();
        });
    }
    document.addEventListener('DOMContentLoaded', initLogoutModal);
</script>
