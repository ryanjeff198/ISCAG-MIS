<?php $active_page = 'apartment_soa'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ISCAG MIS — Official Statement of Account</title>
  <link rel="icon" type="image/x-icon" href="<?= asset('assets/favicon_io/favicon.ico') ?>">
  <link rel="stylesheet" href="<?= asset('css/user-shared.css') ?>" />
  <style>
    /* Fix sidebar icon size issue on hover */
    .sidebar .nav-item svg, 
    .sidebar .nav-dropdown-trigger svg {
      width: 20px !important;
      height: 20px !important;
    }
    .nav-dropdown a svg {
      width: 14px !important;
      height: 14px !important;
    }
    
    /* Exact style clone from Admin SOA */
    :root {
      --primary: #176b45;
      --primary-dark: #0e452c;
      --danger: #d93025;
      --success: #2f8a60;
      --text-main: #202124;
      --text-muted: #5f6368;
      --border: #dadce0;
    }
    .soa-container { background: white; border-radius: 12px; border: 1px solid var(--border); padding: 40px; max-width: 900px; margin: 20px auto; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05); }
    .soa-header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid var(--primary-dark); padding-bottom: 20px; margin-bottom: 30px; }
    .soa-brand { display: flex; align-items: center; gap: 15px; }
    .soa-brand img { width: 80px; height: 80px; border-radius: 8px; }
    .soa-brand-text h2 { margin: 0; color: var(--primary-dark); font-size: 1.5rem; font-family: inherit; }
    .soa-brand-text p { margin: 5px 0 0; font-size: 0.85rem; color: var(--text-muted); }
    .soa-title { text-align: right; }
    .soa-title h1 { margin: 0; color: var(--text-main); font-size: 2rem; text-transform: uppercase; letter-spacing: 2px; }
    .soa-title p { margin: 5px 0 0; color: var(--text-muted); font-weight: 600; font-size: 0.9rem; }
    .soa-details { display: flex; justify-content: space-between; margin-bottom: 30px; background: #f8f9fa; padding: 20px; border-radius: 8px; }
    .soa-details-left p, .soa-details-right p { margin: 5px 0; font-size: 0.95rem; }
    .soa-details strong { color: var(--primary-dark); }
    .soa-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; border: 1px solid var(--border); }
    .soa-table th { background: var(--primary-dark); color: white; padding: 12px; text-align: left; font-size: 0.85rem; border: 1px solid var(--border); }
    .soa-table td { padding: 10px 12px; border: 1px solid var(--border); font-size: 0.9rem; }
    .soa-table tr:hover { background: #f8faf9; }
    .type-badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.03em; }
    .type-badge.rent { background: rgba(23,107,69,0.1); color: #176b45; }
    .type-badge.deposit { background: rgba(59,130,246,0.1); color: #2563eb; }
    .type-badge.advance { background: rgba(139,92,246,0.1); color: #7c3aed; }
    .type-badge.parking { background: rgba(245,158,11,0.1); color: #b45309; }
    .type-badge.water { background: rgba(6,182,212,0.1); color: #0891b2; }
    .type-badge.payment { background: rgba(34,197,94,0.1); color: #16a34a; }
    .type-badge.contribution { background: rgba(156,163,175,0.15); color: #4b5563; }
    .type-badge.moveout { background: rgba(220,38,38,0.1); color: #dc2626; }
    .soa-summary { width: 100%; max-width: 400px; margin-left: auto; }
    .soa-summary-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid var(--border); font-size: 0.95rem; }
    .soa-summary-row.total { font-size: 1.2rem; font-weight: 700; color: var(--primary-dark); border-bottom: none; border-top: 2px solid var(--primary-dark); margin-top: 10px; padding-top: 15px; }
    .soa-section-title { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; color: var(--primary); padding: 12px; background: rgba(23,107,69,0.04); border-left: 3px solid var(--primary); }
    .breakdown-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 24px; padding: 0 12px; }
    .breakdown-card { background: #f8faf9; border-radius: 10px; padding: 14px 16px; border: 1px solid var(--border); }
    .breakdown-card .bk-label { font-size: 0.68rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-muted); margin-bottom: 6px; }
    .breakdown-card .bk-value { font-size: 1.1rem; font-weight: 700; color: var(--text-main); }
    .btn-topbar.primary { background: var(--primary); color: white; display: flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 8px; border: none; cursor: pointer; transition: 0.2s; }
    .btn-topbar.primary:hover { filter: brightness(1.1); transform: translateY(-1px); }

    /* Filter Bar */
    .soa-filter-bar { display: flex; align-items: center; gap: 12px; padding: 16px 20px; background: linear-gradient(to right, #f8fdfb, #f1f8f5); border: 1px solid var(--border); border-radius: 12px; margin-bottom: 20px; flex-wrap: wrap; }
    .soa-filter-bar label { font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-muted); white-space: nowrap; }
    .soa-filter-group { display: flex; align-items: center; gap: 8px; }
    .soa-filter-toggle { display: inline-flex; background: #e8ede9; border-radius: 8px; overflow: hidden; border: 1px solid var(--border); }
    .soa-filter-toggle-btn { padding: 6px 14px; font-size: 0.78rem; font-weight: 600; border: none; background: transparent; color: var(--text-muted); cursor: pointer; transition: all 0.2s ease; font-family: inherit; white-space: nowrap; }
    .soa-filter-toggle-btn.active { background: var(--primary); color: white; box-shadow: 0 2px 8px rgba(23, 107, 69, 0.25); }
    .soa-filter-toggle-btn:hover:not(.active) { background: rgba(23, 107, 69, 0.08); color: var(--primary-dark); }
    .soa-filter-date { padding: 6px 10px; border: 1.5px solid var(--border); border-radius: 8px; font-size: 0.8rem; font-family: inherit; color: var(--text-main); background: white; transition: border-color 0.2s; }
    .soa-filter-date:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(23, 107, 69, 0.1); }
    .soa-filter-clear { padding: 6px 12px; font-size: 0.75rem; font-weight: 600; border: 1.5px solid var(--border); border-radius: 8px; background: white; color: var(--text-muted); cursor: pointer; transition: all 0.2s; font-family: inherit; }
    .soa-filter-clear:hover { border-color: #dc2626; color: #dc2626; background: #fef2f2; }
    .soa-filter-separator { width: 1px; height: 24px; background: var(--border); margin: 0 4px; }
    .soa-filter-count { font-size: 0.75rem; color: var(--text-muted); font-weight: 600; margin-left: auto; white-space: nowrap; }
    tr.soa-hidden { display: none !important; }

    @media print {
      body * { visibility: hidden; }
      .soa-container, .soa-container * { visibility: visible; }
      .soa-container { position: absolute; left: 0; top: 0; width: 100%; max-width: 100%; box-shadow: none; border: none; margin: 0; padding: 20px; }
      .top-bar, .sidebar, .soa-filter-bar { display: none !important; }
    }
  </style>
</head>

<body>
  <div class="app-wrapper">
    <!-- ═══ USER SIDEBAR ═══ -->
    <?php include BASE_PATH . '/app/views/user/sidebar.php'; ?>

    <!-- ═══ MAIN CONTENT ═══ -->
    <main class="main-content">
      <div class="top-bar">
        <div class="top-bar-left">
          <div>
            <div class="top-bar-title">Statement of Account</div>
            <div class="top-bar-subtitle">Your official billing history and current balance</div>
          </div>
        </div>
        <div class="top-bar-actions" style="display:flex; gap:10px;">
          <button class="btn-topbar" style="background:white; color:#15803d; border:1.5px solid #bbf7d0; font-weight:700;" onclick="exportSoaToExcel()">
            <svg viewBox="0 0 24 24" style="width:16px;height:16px;fill:currentColor;"><path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>
            Export to Excel
          </button>
          <button class="btn-topbar primary" onclick="window.print()">
            <svg viewBox="0 0 24 24" style="width:16px;height:16px;fill:currentColor;"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/></svg>
            Print Statement
          </button>
        </div>
      </div>

      <div class="page-body">
        
        <?php if (!$lease): ?>
          <div style="text-align:center; padding:60px 20px; background:white; border-radius:12px; border:1px solid var(--border);">
            <p>No active lease found. Your statement will appear here once your application is final.</p>
          </div>
        <?php else: 
          // Metrics same as Admin logic
          $metrics = ['Rent' => 0, 'Deposit' => 0, 'Parking' => 0, 'Water' => 0, 'Contribution' => 0, 'Payments' => 0];
          foreach($transactions as $t) {
            if($t['payment'] > 0) $metrics['Payments'] += $t['payment'];
            else {
              $type = strtolower($t['type']);
              if(strpos($type, 'rent') !== false) $metrics['Rent'] += $t['charge'];
              elseif(strpos($type, 'deposit') !== false) $metrics['Deposit'] += $t['charge'];
              elseif(strpos($type, 'parking') !== false) $metrics['Parking'] += $t['charge'];
              elseif(strpos($type, 'water') !== false) $metrics['Water'] += $t['charge'];
              elseif(strpos($type, 'contribution') !== false) $metrics['Contribution'] += $t['charge'];
            }
          }
        ?>
        <!-- Filter Bar -->
        <div class="soa-filter-bar" id="soaFilterBar">
          <div class="soa-filter-group">
            <label>Month:</label>
            <form method="GET" action="" style="display:inline; margin:0;">
              <select name="month" id="monthFilter" onchange="this.form.submit()" style="padding: 6px 12px; border-radius: 8px; border: 1.5px solid var(--border); font-family: inherit; font-size: 0.8rem; background: white; cursor: pointer;">
                <option value="all" <?= $filterMonth === 'all' ? 'selected' : '' ?>>All Time</option>
                <?php foreach ($availableMonths as $am): 
                  $amLabel = date('F Y', strtotime($am . '-01'));
                ?>
                  <option value="<?= $am ?>" <?= $filterMonth === $am ? 'selected' : '' ?>><?= $amLabel ?></option>
                <?php endforeach; ?>
              </select>
            </form>
          </div>
          <div class="soa-filter-separator"></div>
          <div class="soa-filter-group">
            <label>Show:</label>
            <div class="soa-filter-toggle">
              <button type="button" class="soa-filter-toggle-btn active" data-filter="unpaid" onclick="setSoaStatusFilter('unpaid', this)">Unpaid</button>
              <button type="button" class="soa-filter-toggle-btn" data-filter="all" onclick="setSoaStatusFilter('all', this)">All</button>
            </div>
          </div>
          <div class="soa-filter-separator"></div>
          <div class="soa-filter-group">
            <label>From:</label>
            <input type="date" class="soa-filter-date" id="soaDateFrom" onchange="applySoaFilters()">
          </div>
          <div class="soa-filter-group">
            <label>To:</label>
            <input type="date" class="soa-filter-date" id="soaDateTo" onchange="applySoaFilters()">
          </div>
          <button type="button" class="soa-filter-clear" onclick="clearSoaFilters()" title="Reset filters">
            <svg viewBox="0 0 24 24" style="width:12px;height:12px;fill:currentColor;vertical-align:-2px;margin-right:3px;"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
            Clear
          </button>
          <span class="soa-filter-count" id="soaFilterCount"></span>
        </div>

        <!-- Statement Document (The Exact Admin View) -->
        <div class="soa-container">
          <div class="soa-header">
            <div class="soa-brand">
              <img src="<?= asset('assets/logo.jpg') ?>" alt="ISCAG Logo">
              <div class="soa-brand-text">
                <h2>ISCAG Management Information System</h2>
                <p>Darul Iman Apartment Complex</p>
                <p>Dasmariñas, Cavite, Philippines</p>
              </div>
            </div>
            <div class="soa-title">
              <h1>Statement of Account</h1>
              <p>Generated on: <?= date('F d, Y') ?></p>
            </div>
          </div>

          <div class="soa-details">
            <div class="soa-details-left">
              <p>Bill To:</p>
              <?php
                $tName = trim(($lease['first_name'] ?? '') . ' ' . ($lease['last_name'] ?? ''));
                if (!$tName) $tName = $_SESSION['user_full_name'] ?? $_SESSION['name'] ?? 'Tenant';
              ?>
              <p><strong style="font-size:1.2rem;"><?= htmlspecialchars($tName) ?></strong></p>
              <p>Unit: <strong><?= (!empty($lease['building']) && !empty($lease['room_number'])) ? htmlspecialchars($lease['building'] . '-' . $lease['room_number']) : 'Unassigned' ?></strong></p>
              <p>Email: <?= htmlspecialchars($lease['email'] ?? '') ?></p>
            </div>
            <div class="soa-details-right" style="text-align: right;">
              <p>Statement Period:</p>
              <p><strong><?= $filterMonth === 'all' ? 'All Time' : date('F Y', strtotime($filterMonth . '-01')) ?></strong></p>
              <p style="margin-top:8px;">Occupants: <strong><?= $occupants ?> person(s)</strong></p>
              <p>Room Type: <strong><?= htmlspecialchars($lease['roomtype'] ?? 'Apartment') ?></strong></p>
            </div>
          </div>

          <!-- Exact Breakdown Cards -->
          <div class="breakdown-grid">
            <?php if ($metrics['Rent'] > 0): ?>
            <div class="breakdown-card">
              <div class="bk-label"><?= $filterMonth === 'all' ? 'Total Rent' : 'Monthly Rent' ?></div>
              <div class="bk-value">₱<?= number_format($metrics['Rent'], 2) ?></div>
              <div class="bk-sub"><?= htmlspecialchars($lease['roomtype'] ?? 'Unit Fee') ?><?= $filterMonth === 'all' ? ' (₱' . number_format($lease['monthly_rent'], 2) . '/mo)' : '' ?></div>
            </div>
            <?php endif; ?>

            <?php if ($metrics['Deposit'] > 0): ?>
            <div class="breakdown-card">
              <div class="bk-label">Security Deposit</div>
              <div class="bk-value">₱<?= number_format($metrics['Deposit'], 2) ?></div>
              <div class="bk-sub">Refundable at end of lease</div>
            </div>
            <?php endif; ?>

            <?php if ($metrics['Parking'] > 0): ?>
            <div class="breakdown-card">
              <div class="bk-label"><?= $filterMonth === 'all' ? 'Total Parking' : 'Parking Fee' ?></div>
              <div class="bk-value">₱<?= number_format($metrics['Parking'], 2) ?></div>
            </div>
            <?php endif; ?>

            <?php if ($metrics['Water'] > 0): ?>
            <div class="breakdown-card">
              <div class="bk-label"><?= $filterMonth === 'all' ? 'Total Water' : 'Water Bill' ?></div>
              <div class="bk-value">₱<?= number_format($metrics['Water'], 2) ?></div>
              <div class="bk-sub"><?= $occupants ?> person(s)</div>
            </div>
            <?php endif; ?>

            <?php if ($metrics['Contribution'] > 0): ?>
            <div class="breakdown-card">
              <div class="bk-label"><?= $filterMonth === 'all' ? 'Total Contribution' : 'Monthly Contribution' ?></div>
              <div class="bk-value">₱<?= number_format($metrics['Contribution'], 2) ?></div>
              <div class="bk-sub">Security & Garbage</div>
            </div>
            <?php endif; ?>

            <?php if (!empty($advanceCreditsTotal) && $advanceCreditsTotal > 0): ?>
            <div class="breakdown-card" style="border-color: #bbf7d0; background: #f0fdf4;">
              <div class="bk-label" style="color: #166534;">Advance Credits</div>
              <div class="bk-value" style="color: #166534;">₱<?= number_format($advanceCreditsTotal, 2) ?></div>
              <div class="bk-sub" style="color: #166534; font-size:0.75rem;">Covering upcoming dues</div>
            </div>
            <?php endif; ?>
          </div>

          <table class="soa-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Description</th>
                <th>Reference</th>
                <th style="text-align:right;">Charge</th>
                <th style="text-align:right;">Payment</th>
                <th style="text-align:right;">Balance</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              // Initialize running balance with the forwarded balance from previous months
              $runningBalance = $balanceForwarded ?? 0; 
              $totalCharges = 0; 
              $totalPayments = 0;
              $lastPeriod = '';
              $sectionIndex = 0;
              $rowIndex = 0;

              if (($filterMonth ?? 'all') !== 'all' && $runningBalance != 0): ?>
                <tr class="soa-balance-forwarded">
                  <td colspan="6"><strong>Balance Forwarded from Previous Months (<?= $runningBalance < 0 ? 'Overpayment Credit' : 'Unpaid Balance' ?>)</strong></td>
                  <td style="text-align:right; font-weight:700; color:<?= $runningBalance > 0 ? 'var(--danger)' : 'var(--success)' ?>"><?= $runningBalance < 0 ? '-' : '' ?>₱<?= number_format(abs($runningBalance), 2) ?></td>
                </tr>
              <?php endif;

              if (empty($transactions)): ?>
                <tr>
                  <td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted); font-size:0.95rem;">
                    No billing transactions found for this period.
                  </td>
                </tr>
              <?php endif;

              foreach ($transactions as $t): 
                $period = $t['period'] ?? getCategoryLabel($t['type']);
                if ($period !== $lastPeriod): 
                  $sectionIndex++;
                ?>
                  <tr class="soa-section-row" data-section-idx="<?= $sectionIndex ?>" data-period="<?= htmlspecialchars($period) ?>"><td colspan="7" class="soa-section-title"><?= $period ?></td></tr>
                  <?php $lastPeriod = $period; 
                endif;

                $runningBalance += ($t['charge'] - $t['payment']);
                $totalCharges += $t['charge'];
                $totalPayments += $t['payment'];
              ?>
              <tr class="<?= $t['payment'] > 0 ? 'row-payment' : 'row-charge' ?> soa-data-row" data-section-idx="<?= $sectionIndex ?>" data-orig-idx="<?= $rowIndex++ ?>" data-row-type="<?= $t['payment'] > 0 ? 'paid' : 'unpaid' ?>" data-row-date="<?= date('Y-m-d', strtotime($t['date'])) ?>">
                <td><?= date('Y-m-d', strtotime($t['date'])) ?></td>
                <td><span class="type-badge <?= getBadgeClass($t['type']) ?>"><?= $t['type'] ?></span></td>
                <td><?= htmlspecialchars($t['description']) ?></td>
                <td style="font-family:monospace; font-size:0.8rem;"><?= htmlspecialchars($t['ref']) ?></td>
                <td style="text-align:right;"><?= $t['charge'] > 0 ? '₱'.number_format($t['charge'], 2) : '-' ?></td>
                <td style="text-align:right; color:var(--success);"><?= $t['payment'] > 0 ? '₱'.number_format($t['payment'], 2) : '-' ?></td>
                <td style="text-align:right; font-weight:700; color:<?= $runningBalance > 0 ? 'var(--danger)' : 'var(--success)' ?>">₱<?= number_format($runningBalance, 2) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>


          <div class="soa-summary">
            <div class="soa-summary-row">
              <span class="label-muted">Total Charges:</span>
              <span>₱<?= number_format($totalCharges ?? 0, 2) ?></span>
            </div>
            <div class="soa-summary-row">
              <span class="label-muted">Total Payments:</span>
              <span style="color:var(--success);">₱<?= number_format($totalPayments ?? 0, 2) ?></span>
            </div>
            <div class="soa-summary-row total">
              <span>Outstanding Balance:</span>
              <span style="color:<?= ($runningBalance ?? 0) > 0 ? 'var(--danger)' : 'var(--success)' ?>">₱<?= number_format($runningBalance ?? 0, 2) ?></span>
            </div>
          </div>
          
          <div style="margin-top: 50px; text-align: center; color: var(--text-muted); font-size: 0.85rem; border-top: 1px solid var(--border); padding-top: 20px;">
            <p>If you have any questions regarding this statement, please contact the Apartment Admin.</p>
            <p>This is a system-generated document and acts as an official statement of account.</p>
          </div>

        </div>
        <?php endif; ?>
      </div>
    </main>
  </div>

  <script>
    // ─── SOA Filter & Sorting Logic ───
    let soaStatusFilter = 'unpaid';

    function sortSoaRows(order) {
      const tbody = document.querySelector('.soa-table tbody');
      if (!tbody) return;

      const sectionRows = Array.from(tbody.querySelectorAll('.soa-section-row'));
      const balanceRow = tbody.querySelector('.soa-balance-forwarded');

      if (sectionRows.length === 0) {
        const dataRows = Array.from(tbody.querySelectorAll('.soa-data-row'));
        dataRows.sort((a, b) => {
          if (order === 'desc') {
            const dateA = a.getAttribute('data-row-date') || '';
            const dateB = b.getAttribute('data-row-date') || '';
            if (dateA !== dateB) return dateB.localeCompare(dateA);
            return (parseInt(b.getAttribute('data-orig-idx') || 0)) - (parseInt(a.getAttribute('data-orig-idx') || 0));
          } else {
            return (parseInt(a.getAttribute('data-orig-idx') || 0)) - (parseInt(b.getAttribute('data-orig-idx') || 0));
          }
        });
        if (balanceRow) {
          if (order === 'desc') tbody.appendChild(balanceRow);
          else tbody.insertBefore(balanceRow, tbody.firstChild);
        }
        dataRows.forEach(r => tbody.appendChild(r));
        return;
      }

      // Group section headers with their data rows
      const groups = [];
      sectionRows.forEach(sRow => {
        const sIdx = sRow.getAttribute('data-section-idx');
        const dataRows = Array.from(tbody.querySelectorAll(`.soa-data-row[data-section-idx="${sIdx}"]`));

        let maxDate = '';
        dataRows.forEach(r => {
          const d = r.getAttribute('data-row-date') || '';
          if (!maxDate || d > maxDate) maxDate = d;
        });

        groups.push({
          sectionRow: sRow,
          dataRows: dataRows,
          sectionIdx: parseInt(sIdx) || 0,
          maxDate: maxDate
        });
      });

      if (order === 'desc') {
        // Latest period section on top, oldest on bottom
        groups.sort((a, b) => {
          if (b.maxDate !== a.maxDate) {
            return b.maxDate.localeCompare(a.maxDate);
          }
          return b.sectionIdx - a.sectionIdx;
        });

        // Within each section, sort data rows latest to oldest
        groups.forEach(g => {
          g.dataRows.sort((a, b) => {
            const dateA = a.getAttribute('data-row-date') || '';
            const dateB = b.getAttribute('data-row-date') || '';
            if (dateA !== dateB) {
              return dateB.localeCompare(dateA);
            }
            return (parseInt(b.getAttribute('data-orig-idx') || 0)) - (parseInt(a.getAttribute('data-orig-idx') || 0));
          });
        });
      } else {
        // Natural chronological order: sectionIdx ASC
        groups.sort((a, b) => a.sectionIdx - b.sectionIdx);

        // Within each section, original order: data-orig-idx ASC
        groups.forEach(g => {
          g.dataRows.sort((a, b) => {
            return (parseInt(a.getAttribute('data-orig-idx') || 0)) - (parseInt(b.getAttribute('data-orig-idx') || 0));
          });
        });
      }

      // Rebuild tbody in sorted order
      if (balanceRow && order === 'asc') {
        tbody.appendChild(balanceRow);
      }

      groups.forEach(g => {
        tbody.appendChild(g.sectionRow);
        g.dataRows.forEach(r => tbody.appendChild(r));
      });

      if (balanceRow && order === 'desc') {
        tbody.appendChild(balanceRow);
      }
    }

    function setSoaStatusFilter(filter, btn) {
      soaStatusFilter = filter;
      document.querySelectorAll('.soa-filter-toggle-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      sortSoaRows('desc');
      applySoaFilters();
    }

    function applySoaFilters() {
      const rows = document.querySelectorAll('.soa-data-row');
      const dateFrom = document.getElementById('soaDateFrom')?.value || '';
      const dateTo = document.getElementById('soaDateTo')?.value || '';
      let visibleCount = 0;
      const totalCount = rows.length;

      rows.forEach(row => {
        const type = row.getAttribute('data-row-type');
        const date = row.getAttribute('data-row-date');
        let show = true;

        // Status filter
        if (soaStatusFilter === 'unpaid' && type === 'paid') {
          show = false;
        }

        // Date range filter
        if (show && dateFrom && date < dateFrom) {
          show = false;
        }
        if (show && dateTo && date > dateTo) {
          show = false;
        }

        if (show) {
          row.classList.remove('soa-hidden');
          visibleCount++;
        } else {
          row.classList.add('soa-hidden');
        }
      });

      // Auto-hide section headers that have no visible data rows following them
      const sectionRows = document.querySelectorAll('.soa-section-row');
      sectionRows.forEach(section => {
        let hasVisible = false;
        let sibling = section.nextElementSibling;
        while (sibling && !sibling.classList.contains('soa-section-row')) {
          if (sibling.classList.contains('soa-data-row') && !sibling.classList.contains('soa-hidden')) {
            hasVisible = true;
            break;
          }
          sibling = sibling.nextElementSibling;
        }
        section.classList.toggle('soa-hidden', !hasVisible);
      });

      // Update results count
      const countEl = document.getElementById('soaFilterCount');
      if (countEl) {
        countEl.textContent = visibleCount + ' of ' + totalCount + ' transaction(s)';
      }
    }

    function clearSoaFilters() {
      soaStatusFilter = 'unpaid';
      document.querySelectorAll('.soa-filter-toggle-btn').forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-filter') === 'unpaid');
      });
      const dateFrom = document.getElementById('soaDateFrom');
      const dateTo = document.getElementById('soaDateTo');
      if (dateFrom) dateFrom.value = '';
      if (dateTo) dateTo.value = '';
      sortSoaRows('desc');
      applySoaFilters();
    }

    // Apply default filter on page load (always latest to oldest)
    document.addEventListener('DOMContentLoaded', function() {
      sortSoaRows('desc');
      applySoaFilters();
    });

    // ─── Excel Export ───
    function exportSoaToExcel() {
      const soaContainer = document.querySelector('.soa-container');
      if (!soaContainer) return;

      const table = soaContainer.querySelector('.soa-table');
      if (!table) return;

      const tenantName = "<?= addslashes(htmlspecialchars_decode(($lease['first_name'] ?? '') . ' ' . ($lease['last_name'] ?? 'Tenant'), ENT_QUOTES)) ?>";
      const unit = "<?= addslashes((!empty($lease['building']) && !empty($lease['room_number'])) ? ($lease['building'] . '-' . $lease['room_number']) : 'Unassigned') ?>";
      const period = "<?= addslashes(($filterMonth === 'all') ? 'All Time' : date('F Y', strtotime($filterMonth . '-01'))) ?>";
      const dateGen = "<?= date('Y-m-d') ?>";

      let html = `
        <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
          <!--[if gte mso 9]>
          <xml>
            <x:ExcelWorkbook>
              <x:ExcelWorksheets>
                <x:ExcelWorksheet>
                  <x:Name>Statement of Account</x:Name>
                  <x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions>
                </x:ExcelWorksheet>
              </x:ExcelWorksheets>
            </x:ExcelWorkbook>
          </xml>
          <![endif]-->
          <meta http-equiv="content-type" content="text/plain; charset=UTF-8"/>
          <style>
            table { border-collapse: collapse; font-family: Arial, sans-serif; font-size: 11pt; }
            th { background-color: #176b45; color: #ffffff; border: 1px solid #cccccc; padding: 8px 12px; font-weight: bold; }
            td { border: 1px solid #cccccc; padding: 6px 10px; }
            .header-title { font-size: 14pt; font-weight: bold; color: #0e452c; }
            .meta-label { font-weight: bold; color: #555555; }
            .total-row { font-weight: bold; background-color: #f3f4f6; }
          </style>
        </head>
        <body>
          <table>
            <tr><td colspan="7" class="header-title">ISCAG MANAGEMENT INFORMATION SYSTEM</td></tr>
            <tr><td colspan="7" style="font-weight:bold; color:#176b45;">Darul Iman Apartment Complex — Statement of Account</td></tr>
            <tr><td colspan="7">Generated on: ${dateGen}</td></tr>
            <tr><td colspan="7"></td></tr>
            <tr>
              <td class="meta-label">Tenant:</td>
              <td colspan="2">${tenantName}</td>
              <td class="meta-label">Statement Period:</td>
              <td colspan="3">${period}</td>
            </tr>
            <tr>
              <td class="meta-label">Unit:</td>
              <td colspan="2">${unit}</td>
              <td class="meta-label">Total Outstanding:</td>
              <td colspan="3" style="font-weight:bold; color:#d93025;">PHP <?= number_format($runningBalance ?? 0, 2) ?></td>
            </tr>
            <tr><td colspan="7"></td></tr>
          </table>
          ${table.outerHTML}
          <table>
            <tr><td colspan="7"></td></tr>
            <tr class="total-row">
              <td colspan="4" style="text-align:right;">Total Charges:</td>
              <td colspan="3">PHP <?= number_format($totalCharges ?? 0, 2) ?></td>
            </tr>
            <tr class="total-row">
              <td colspan="4" style="text-align:right;">Total Payments:</td>
              <td colspan="3" style="color:#15803d;">PHP <?= number_format($totalPayments ?? 0, 2) ?></td>
            </tr>
            <tr class="total-row" style="font-size:12pt; background-color:#e6f4ea;">
              <td colspan="4" style="text-align:right;">Outstanding Balance:</td>
              <td colspan="3" style="font-weight:bold; color:<?= ($runningBalance ?? 0) > 0 ? '#d93025' : '#15803d' ?>;">PHP <?= number_format($runningBalance ?? 0, 2) ?></td>
            </tr>
          </table>
        </body>
        </html>
      `;

      const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const safeTenant = tenantName.replace(/[^a-zA-Z0-9_-]/g, '_');
      a.href = url;
      a.download = `SOA_${safeTenant}_${dateGen}.xls`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  </script>
</body>
</html>

<?php
function getCategoryLabel($type) {
  $t = strtolower($type);
  if (strpos($t, 'rent') !== false && strpos($t, 'payment') === false) return 'Apartment Rent';
  if (strpos($t, 'deposit') !== false || strpos($t, 'advance') !== false) return 'Initial Payments';
  if (strpos($t, 'parking') !== false) return 'Parking';
  if (strpos($t, 'water') !== false) return 'Water Consumption';
  if (strpos($t, 'contribution') !== false) return 'Contribution';
  if (strpos($t, 'damage') !== false || strpos($t, 'move-out') !== false) return 'Move-Out Settlement';
  if (strpos($t, 'payment') !== false) return 'Payment Records';
  return 'Other';
}
function getBadgeClass($type) {
  $t = strtolower($type);
  if (strpos($t, 'rent') !== false) return 'rent';
  if (strpos($t, 'deposit') !== false) return 'deposit';
  if (strpos($t, 'advance') !== false) return 'advance';
  if (strpos($t, 'parking') !== false) return 'parking';
  if (strpos($t, 'water') !== false) return 'water';
  if (strpos($t, 'contribution') !== false) return 'contribution';
  if (strpos($t, 'damage') !== false || strpos($t, 'move-out') !== false) return 'moveout';
  if (strpos($t, 'payment') !== false) return 'payment';
  return '';
}
?>
