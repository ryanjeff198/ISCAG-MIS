<?php 
$active_page = 'notifications'; 
if (!function_exists('asset')) {
    function asset($path) { 
        $baseUrl = str_replace('/public/index.php', '', str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''));
        $baseUrl = rtrim($baseUrl, '/');
        if (str_ends_with($baseUrl, '/public')) return $baseUrl . '/' . ltrim($path, '/');
        return $baseUrl . "/public/" . ltrim($path, '/'); 
    }
}
if (!function_exists('url')) {
    function url($path) { 
        $baseUrl = str_replace('/public/index.php', '', str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''));
        return rtrim($baseUrl, '/') . "/" . ltrim($path, '/'); 
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ISCAG MIS — Send Notifications</title>
    <link rel="icon" type="image/x-icon" href="<?= asset('assets/favicon_io/favicon.ico') ?>">
    <link rel="stylesheet" href="<?= asset('css/admin-shared.css') ?>" />
</head>

<body>
    <div class="app-wrapper">

        <!-- ═══ SIDEBAR ═══ -->
        <?php include BASE_PATH . '/app/views/components/mis_admin_sidebar.php'; ?>

        <!-- ═══ MAIN CONTENT ═══ -->
        <main class="main-content">
            <div class="top-bar">
                <div class="top-bar-left">
                    
                    <div>
                        <div class="top-bar-title">Notification Broadcast Hub</div>
                        <div class="top-bar-subtitle">Create and send instant alerts to specific users or entire departments.</div>
                    </div>
                </div>
                <div class="top-bar-actions">
                    <a href="<?= url('/admin/dashboard') ?>" class="btn-topbar">← Dashboard</a>
                </div>
            </div>

            <div class="page-body">
                
                <!-- Admin Insights Ribbon -->
                <div class="admin-insights">
                    <div class="insight-card">
                        <div class="insight-label">Recent Broadcasts</div>
                        <div class="insight-value info" id="stat-sent-val">0</div>
                    </div>
                    <div class="insight-card">
                        <div class="insight-label">Delivery Status</div>
                        <div class="insight-value success">100%</div>
                    </div>
                    <div class="insight-card">
                        <div class="insight-label">Open Rate</div>
                        <div class="insight-value info">72.4%</div>
                    </div>
                    <div class="insight-card">
                        <div class="insight-label">Active Audience</div>
                        <div class="insight-value">1,248</div>
                    </div>
                </div>
                
                <div class="split-layout">
                    <!-- COMPOSE FORM -->
                    <div class="compose-card">
                        <div class="compose-header">
                            <svg viewBox="0 0 24 24" style="width:24px;height:24px;fill:currentColor;"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                            Compose Message
                        </div>
                        <form id="broadcast-form" onsubmit="event.preventDefault(); sendBroadcast();">
                            <div class="form-row">
                                <label class="form-label">Target Audience</label>
                                <select class="form-control" id="target-audience" required onchange="toggleSpecificUser()">
                                    <option value="">— Select Target Demographic —</option>
                                    <option value="ALL">Global (All Registered Users)</option>
                                    <option value="APARTMENT">Apartment Tenants Only</option>
                                    <option value="DAMAYAN">Damayan Members Only</option>
                                    <option value="DAWAH">Da'wah Members Only</option>
                                    <option value="SPECIFIC">Specific User...</option>
                                </select>
                            </div>
                            
                            <div class="form-row" id="specific-user-row" style="display:none;">
                                <label class="form-label">Select Specific User</label>
                                <select class="form-control" id="target-specific-user">
                                    <option value="">— Choose a User —</option>
                                    <option value="USR-001">Muhammad Usman (Apartment)</option>
                                    <option value="USR-002">Aisha Fatima (Da'wah)</option>
                                    <option value="USR-003">Omar Khan (Damayan)</option>
                                </select>
                            </div>

                            <div class="form-row">
                                <label class="form-label">Notification Type</label>
                                <select class="form-control" id="notif-type" required>
                                    <option value="system">System Announcement (Default)</option>
                                    <option value="alert">Important Alert / Warning</option>
                                    <option value="request">Update on Request</option>
                                    <option value="payment">Billing / Payment Notice</option>
                                </select>
                            </div>

                            <div class="form-row">
                                <label class="form-label">Message Title</label>
                                <input type="text" class="form-control" id="notif-title" placeholder="E.g., Scheduled Maintenance Next Week" required />
                            </div>

                            <div class="form-row">
                                <label class="form-label">Message Body</label>
                                <textarea class="form-control" id="notif-body" rows="6" placeholder="Type your full announcement or message here..." required></textarea>
                            </div>

                            <button type="submit" class="btn-submit">
                                <svg viewBox="0 0 24 24" style="width:18px;height:18px;fill:currentColor;"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
                                Send Notification Now
                            </button>
                        </form>
                    </div>

                    <!-- SENT HISTORY -->
                    <div class="history-card">
                        <div class="compose-header" style="border-bottom:1px solid var(--border); padding:20px; background:#fcfcfc; margin:0;">
                            <svg viewBox="0 0 24 24" style="width:24px;height:24px;fill:currentColor;"><path d="M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9z"/></svg>
                            Recent Broadcasts
                        </div>
                        <div class="history-list" id="sent-list">
                            <!-- JS injected -->
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <!-- NOTIFICATION TOAST -->
    <div id="toast" style="visibility:hidden;min-width:250px;background:#333;color:#fff;text-align:center;border-radius:8px;padding:16px;position:fixed;z-index:9999;bottom:30px;right:30px;font-size:0.9rem;font-weight:600;box-shadow:0 10px 30px rgba(0,0,0,0.2);transition:visibility 0.4s, opacity 0.4s;opacity:0;"></div>

    <script src="<?= asset('JS/admin-shared.js') ?>"></script>
    <script>
        standardizePage('admin');

        // Fetch users for the specific user dropdown
        async function loadUsers() {
            try {
                const res = await fetch('<?= url("/admin/mis_admin/broadcast/users") ?>');
                const users = await res.json();
                const sel = document.getElementById('target-specific-user');
                sel.innerHTML = '<option value="">— Choose a User —</option>';
                users.forEach(u => {
                    const opt = document.createElement('option');
                    opt.value = u.tenant_id;
                    opt.textContent = `${u.first_name} ${u.last_name} (${u.role})`;
                    sel.appendChild(opt);
                });
            } catch (e) { console.error('Failed to load users:', e); }
        }
        loadUsers();

        function toggleSpecificUser() {
            const aud = document.getElementById('target-audience').value;
            const specRow = document.getElementById('specific-user-row');
            if (aud === 'SPECIFIC') {
                specRow.style.display = 'block';
                document.getElementById('target-specific-user').setAttribute('required', 'true');
            } else {
                specRow.style.display = 'none';
                document.getElementById('target-specific-user').removeAttribute('required');
            }
        }

        function getIconForType(type) {
            const map = {
                'system': '<path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>',
                'alert': '<path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>',
                'request': '<path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>',
                'payment': '<path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/>'
            };
            return map[type] || map['system'];
        }

        async function sendBroadcast() {
            const audience = document.getElementById('target-audience').value;
            const specificUser = document.getElementById('target-specific-user').value;
            const type = document.getElementById('notif-type').value;
            const title = document.getElementById('notif-title').value;
            const message = document.getElementById('notif-body').value;

            const btn = document.querySelector('.btn-submit');
            btn.disabled = true;
            btn.innerHTML = 'Sending...';

            try {
                const res = await fetch('<?= url("/admin/mis_admin/broadcast/send") ?>', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ audience, specificUser, type, title, message })
                });
                const data = await res.json();
                
                if (data.success) {
                    showToast(`✅ Successfully broadcasted to ${data.count} user(s).`, 'var(--success)');
                    document.getElementById('broadcast-form').reset();
                    toggleSpecificUser();
                    renderHistory();
                } else {
                    showToast(`❌ Error: ${data.message}`, 'var(--danger)');
                }
            } catch (e) {
                showToast('❌ System failure. Check console.', 'var(--danger)');
                console.error(e);
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<svg viewBox="0 0 24 24" style="width:18px;height:18px;fill:currentColor;"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg> Send Notification Now';
            }
        }

        async function renderHistory() {
            try {
                const res = await fetch('<?= url("/admin/mis_admin/broadcast/history") ?>');
                const broadcasts = await res.json();
                const list = document.getElementById('sent-list');
                
                if (broadcasts.length === 0) {
                    list.innerHTML = `<div style="padding:40px 20px; text-align:center; color:var(--text-muted);">
                        <svg viewBox="0 0 24 24" style="width:40px;height:40px;fill:var(--border);margin-bottom:10px;"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12s4.48 10 10 10 10-4.48 10-10zm-11 5H9v-2h2v2zm0-4H9V7h2v6z"/></svg><br>
                        No broadcasts sent yet.
                    </div>`;
                    return;
                }

                list.innerHTML = '';
                broadcasts.forEach(b => {
                    let d = new Date(b.created_at).toLocaleString('en-US', {month:'short', day:'numeric', hour:'numeric', minute:'2-digit'});
                    const div = document.createElement('div');
                    div.className = 'sent-item';
                    div.innerHTML = `
                        <div class="sent-icon">
                            <svg viewBox="0 0 24 24">${getIconForType(b.type)}</svg>
                        </div>
                        <div class="sent-content">
                            <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                                <h5 style="margin:0;">${b.title}</h5>
                                <div class="action-menu">
                                    <button class="action-menu-btn" onclick="toggleActionMenu(this, event)" title="Actions">
                                        <svg viewBox="0 0 24 24"><path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
                                    </button>
                                    <div class="action-menu-dropdown">
                                        <button class="action-menu-item" onclick="showToast('Resending broadcast...','var(--success)')">
                                            <svg viewBox="0 0 24 24"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
                                            Resend Broadcast
                                        </button>
                                        <button class="action-menu-item danger" onclick="showToast('Broadcast deleted from history','var(--danger)')">
                                            <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                            Delete Forever
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <p>${b.message.substring(0, 80)}${b.message.length > 80 ? '...' : ''}</p>
                            <div class="sent-meta">
                                <span class="target-badge">To: ${b.target_group}</span>
                                <span>${d}</span>
                            </div>
                        </div>
                    `;
                    list.appendChild(div);
                });
            } catch(e) { console.error('Failed to render history:', e); }
        }

        renderHistory();
    </script>
</body>
</html>

