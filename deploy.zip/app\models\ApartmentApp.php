<?php
require_once BASE_PATH . '/config/database.php';

class ApartmentApp {
    private $db;

    public function __construct() {
        $this->db = getDbConnection();
    }

    // ─── tenant_addinfo ───────────────────────────────────
    public function getInfo($userId) {
        $stmt = $this->db->prepare("SELECT * FROM tenant_addinfo WHERE tenant_id = :uid LIMIT 1");
        $stmt->execute(['uid' => $userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }

    public function saveInfo($userId, $data) {
        $allowed = [
            'familyname','givenname','middlename','muslimname',
            'civil_status','address','birthdate','pob','age','sex',
            'tribalaffliation','numofmuslim','occupation','monthly_income',
            'companyname','companyadd','companyphone',
            'dateofshahadah','ref_name','ref_contact',
            'iscag_students','iscag_student_names','is_iscag_employee','iscag_job_role','date_applied','family_data'
        ];
        $safe = [];
        foreach ($allowed as $col) {
            if (array_key_exists($col, $data)) {
                $safe[$col] = $data[$col];
            }
        }
        // If no whitelisted fields were provided, still allow creating a minimal record
        $this->db->beginTransaction();
        try {
            $existing = $this->getInfo($userId);
            if (!$existing) {
                if (empty($safe)) {
                    // Create a minimal record with just tenant_id
                    $sql = "INSERT INTO tenant_addinfo (tenant_id) VALUES (:tenant_id)";
                    $stmt = $this->db->prepare($sql);
                    $stmt->execute(['tenant_id' => $userId]);
                } else {
                    $safe['tenant_id'] = $userId;
                    $cols = implode(',', array_keys($safe));
                    $phs  = implode(',', array_map(fn($k) => ":$k", array_keys($safe)));
                    $sql  = "INSERT INTO tenant_addinfo ($cols) VALUES ($phs)";
                    $stmt = $this->db->prepare($sql);
                    $stmt->execute($safe);
                }
                $lastId = $this->db->lastInsertId();
            } else {
                if (!empty($safe)) {
                    $set = implode(',', array_map(fn($k) => "$k = :$k", array_keys($safe)));
                    $sql = "UPDATE tenant_addinfo SET $set WHERE tenant_id = :tenant_id";
                    $safe['tenant_id'] = $userId;
                    $stmt = $this->db->prepare($sql);
                    $stmt->execute($safe);
                }
                $lastId = $existing['tenant_info'];
            }

            // ── Sync family members to relational table ──
            if (isset($data['family_data'])) {
                $familyJson = $data['family_data'];
                $members = is_string($familyJson) ? json_decode($familyJson, true) : $familyJson;
                
                if (is_array($members)) {
                    // Clear existing members for this tenant
                    $delStmt = $this->db->prepare("DELETE FROM tenant_family_members WHERE tenant_id = ?");
                    $delStmt->execute([$userId]);
                    
                    // Insert fresh members
                    $insStmt = $this->db->prepare(
                        "INSERT INTO tenant_family_members (tenant_id, name, relation, age, religion) VALUES (?, ?, ?, ?, ?)"
                    );
                    foreach ($members as $m) {
                        $name = trim($m['name'] ?? '');
                        if ($name === '') continue; // Skip empty rows
                        $insStmt->execute([
                            $userId,
                            $name,
                            $m['relation'] ?? '',
                            !empty($m['age']) ? (int)$m['age'] : null,
                            $m['religion'] ?? 'Islam'
                        ]);
                    }
                }
            }

            $this->db->commit();
            return $lastId;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log("saveInfo failed: " . $e->getMessage());
            return false;
        }
    }

    public function saveInfoImage($infoId, $docType, $binaryData, $mimeType, $filePath = null) {
        $this->db->beginTransaction();
        try {
            // Upsert logic for tenant_addinfo_images based on addinfo_id and doc_type
            $stmt = $this->db->prepare("SELECT id FROM tenant_addinfo_images WHERE addinfo_id = :info_id AND doc_type = :doc_type LIMIT 1");
            $stmt->execute(['info_id' => $infoId, 'doc_type' => $docType]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                // If we have a filePath, we usually want to clear the old binary data to save space
                $sql = "UPDATE tenant_addinfo_images SET image = :data, mime_type = :mime, file_path = :path WHERE id = :id";
                $stmt = $this->db->prepare($sql);
                $stmt->bindValue(':id', $existing['id'], PDO::PARAM_INT);
            } else {
                $sql = "INSERT INTO tenant_addinfo_images (addinfo_id, doc_type, image, mime_type, file_path) VALUES (:info_id, :doc_type, :data, :mime, :path)";
                $stmt = $this->db->prepare($sql);
                $stmt->bindValue(':info_id', $infoId, PDO::PARAM_INT);
                $stmt->bindValue(':doc_type', $docType, PDO::PARAM_STR);
            }
            // If filePath is set, we can set data to NULL (optional, but good for space)
            $stmt->bindValue(':data', $binaryData, $binaryData === null ? PDO::PARAM_NULL : PDO::PARAM_LOB);
            $stmt->bindValue(':mime', $mimeType, PDO::PARAM_STR);
            $stmt->bindValue(':path', $filePath, $filePath === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
            $result = $stmt->execute();
            $this->db->commit();
            return $result;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log("saveInfoImage failed: " . $e->getMessage());
            return false;
        }
    }

    public function getAddInfoImage($infoId, $docType) {
        $stmt = $this->db->prepare("SELECT image, mime_type, file_path FROM tenant_addinfo_images WHERE addinfo_id = :info_id AND doc_type = :doc_type LIMIT 1");
        $stmt->execute(['info_id' => $infoId, 'doc_type' => $docType]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            return [
                'data' => $row['image'], 
                'mime' => $row['mime_type'] ?: 'image/jpeg',
                'file_path' => $row['file_path']
            ];
        }
        return null;
    }

    public function deleteInfoImage($infoId, $docType) {
        // Fetch path to delete from disk if exists
        $stmt = $this->db->prepare("SELECT file_path FROM tenant_addinfo_images WHERE addinfo_id = :iid AND doc_type = :dt");
        $stmt->execute(['iid' => $infoId, 'dt' => $docType]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['file_path'])) {
            $fullPath = BASE_PATH . "/public/" . $row['file_path'];
            if (file_exists($fullPath)) @unlink($fullPath);
        }

        $stmt = $this->db->prepare("DELETE FROM tenant_addinfo_images WHERE addinfo_id = :iid AND doc_type = :dt");
        return $stmt->execute(['iid' => $infoId, 'dt' => $docType]);
    }

    public function getUploadedDocTypes($userId) {
        $stmt = $this->db->prepare("
            SELECT i.doc_type 
            FROM tenant_addinfo_images i
            JOIN tenant_addinfo t ON i.addinfo_id = t.tenant_info
            WHERE t.tenant_id = :uid
        ");
        $stmt->execute(['uid' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN) ?: [];
    }


    // ─── apartmentsapp (unit type) ────────────────────────
    public function getApplication($userId) {
        $sql = "SELECT a.*, a.application_id as id, u.room_number, u.building, u.status as unit_status 
                FROM apartmentsapp a 
                LEFT JOIN apartment_units u ON a.unit_id = u.unit_id 
                WHERE a.tenant_id = :uid 
                ORDER BY a.application_id DESC LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(['uid' => $userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }

    public function saveApplication($userId, $roomtype) {
        $this->db->beginTransaction();
        try {
            $existing = $this->getApplication($userId);
            if (!$existing || in_array($existing['status'] ?? '', ['Archived', 'Moved-Out', 'Rejected'])) {
                // Initial status is 'Draft' until documents are submitted
                $sql = "INSERT INTO apartmentsapp (tenant_id, roomtype, date, status) VALUES (:uid, :rt, CURDATE(), 'Draft')";
                $stmt = $this->db->prepare($sql);
                $result = $stmt->execute(['uid' => $userId, 'rt' => $roomtype]);
            } else {
                // Keep existing status if already submitted, or update if still in Draft
                $sql = "UPDATE apartmentsapp SET roomtype = :rt WHERE application_id = :aid";
                $stmt = $this->db->prepare($sql);
                $result = $stmt->execute(['rt' => $roomtype, 'aid' => $existing['application_id']]);
            }
            $this->db->commit();
            return $result;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log("saveApplication failed: " . $e->getMessage());
            return false;
        }
    }

    // ─── ADMIN DASHBOARD METHODS ──────────────────────────
    public function getAllApplications() {
        $sql = "
            SELECT 
                a.application_id as id,
                a.tenant_id as tenant_id,
                u.first_name,
                u.last_name,
                u.contactnum as contactnum,
                a.roomtype,
                a.date as submitted_at,
                a.status,
                a.reject_reason,
                a.updated_at,
                a.assigned_at,
                a.accepted_at,
                t.*,
                au.room_number,
                au.building,
                au.description
            FROM apartmentsapp a
            JOIN tenant_accounts u ON a.tenant_id = u.tenant_id
            LEFT JOIN tenant_addinfo t ON a.tenant_id = t.tenant_id
            LEFT JOIN apartment_units au ON a.unit_id = au.unit_id
            WHERE a.status != 'Draft'
            ORDER BY a.application_id DESC
        ";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function updateApplicationStatus($applicationId, $status, $reason = null) {
        $sql = "UPDATE apartmentsapp SET status = :status";
        $params = ['status' => $status, 'id' => $applicationId];
        
        if ($reason !== null) {
            $sql .= ", reject_reason = :reason";
            $params['reason'] = $reason;
        }
        
        $sql .= " WHERE application_id = :id";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    public function getTenantIdByApplicationId($applicationId) {
        $stmt = $this->db->prepare("SELECT tenant_id FROM apartmentsapp WHERE application_id = :id LIMIT 1");
        $stmt->execute(['id' => $applicationId]);
        return $stmt->fetchColumn();
    }

    // ─── PARKING METHODS ──────────────────────────
    public function hasPendingParkingApplication($userId) {
        $stmt = $this->db->prepare("SELECT 1 FROM tenant_parking WHERE tenant_id = :uid AND status = 'Pending' LIMIT 1");
        $stmt->execute(['uid' => $userId]);
        return (bool) $stmt->fetchColumn();
    }

    public function saveParkingApplication($userId, $data) {
        $sql = "INSERT INTO tenant_parking 
                (tenant_id, date, vehiclename, ownername, typeofvehicle, plateno, datestarted, status) 
                VALUES 
                (:tenant_id, :date, :vehiclename, :ownername, :typeofvehicle, :plateno, :datestarted, 'Pending')";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            'tenant_id' => $userId,
            'date' => $data['date'] ?? date('Y-m-d'),
            'vehiclename' => $data['vehicleName'] ?? '',
            'ownername' => $data['vehicleOwner'] ?? '',
            'typeofvehicle' => $data['vehicleType'] ?? '',
            'plateno' => $data['plateNo'] ?? '',
            'datestarted' => $data['dateStarted'] ?? ''
        ]);
    }

    public function getAllParkingApplications() {
        $sql = "
            SELECT 
                p.parking_id as id,
                p.tenant_id as tenant_id,
                u.first_name,
                u.last_name,
                u.email,
                u.contactnum,
                p.ownername,
                p.vehiclename,
                p.plateno,
                p.typeofvehicle,
                p.datestarted,
                p.date as submitted_at,
                p.status,
                p.remarks
            FROM tenant_parking p
            JOIN tenant_accounts u ON p.tenant_id = u.tenant_id
            ORDER BY p.parking_id DESC
        ";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    public function updateParkingStatus($parkingId, $status, $reason = null) {
        $sql = "UPDATE tenant_parking SET status = :status";
        $params = ['status' => $status, 'id' => $parkingId];

        if ($reason !== null) {
            $sql .= ", remarks = :reason";
            $params['reason'] = $reason;
        }

        $sql .= " WHERE parking_id = :id";

        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }



    public function getParkingApplicationsByTenant($userId) {
        $stmt = $this->db->prepare("SELECT * FROM tenant_parking WHERE tenant_id = :uid ORDER BY parking_id DESC");
        $stmt->execute(['uid' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    // ─── TENANT SUBMISSION ──────────────────────────
    public function updateStatusByTenant($userId, $status) {
        $sql = "UPDATE apartmentsapp SET status = :status WHERE tenant_id = :uid";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(['status' => $status, 'uid' => $userId]);
    }

    // ═══════════════════════════════════════════════════
    //  ROOM ASSIGNMENT & WAITLIST ENGINE
    // ═══════════════════════════════════════════════════

    /**
     * Core logic: Assign a room OR add to waitlist.
     * 
     * Flow: 
     *   1. Look up the application's requested room type
     *   2. Find an available room of that type (or transient room with < 10 occupants)
     *   3a. If found → Assign room, mark unit Occupied, update application to Assigned, change role to Tenant
     *   3b. If none  → Calculate queue position, set status to Queued
     *
     * @return array ['result' => 'assigned'|'queued'|'error', 'unit_id' => int|null, 'queue_position' => int|null, 'room_number' => string|null, 'building' => string|null]
     */
    public function assignOrQueue(int $applicationId): array
    {
        // Get the application
        $stmt = $this->db->prepare("SELECT * FROM apartmentsapp WHERE application_id = :id");
        $stmt->execute(['id' => $applicationId]);
        $app = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$app) return ['result' => 'error', 'message' => 'Application not found'];

        $typeId = $this->getTypeIdByLabel($app['roomtype']);
        $room = null;

        // 2. Match tenant preference if possible
        if ($typeId) {
            $isTransient = stripos($app['roomtype'], 'Transient') !== false;

            if ($isTransient) {
                $stmtPref = $this->db->prepare("
                    SELECT u.unit_id, u.room_number, u.building,
                           (SELECT COUNT(*) FROM apartmentsapp a WHERE a.unit_id = u.unit_id AND a.status = 'Assigned') as occupant_count
                    FROM apartment_units u 
                    WHERE u.type_id = :tid 
                      AND u.status IN ('Available', 'Occupied')
                    HAVING occupant_count < 10
                    ORDER BY occupant_count DESC, u.building, u.room_number 
                    LIMIT 1
                ");
            } else {
                $stmtPref = $this->db->prepare("
                    SELECT unit_id, room_number, building 
                    FROM apartment_units 
                    WHERE type_id = :tid AND status = 'Available' 
                    ORDER BY building, room_number 
                    LIMIT 1
                ");
            }
            $stmtPref->execute(['tid' => $typeId]);
            $room = $stmtPref->fetch(PDO::FETCH_ASSOC);
        }

        // 3. Otherwise assign first available (FIFO)
        if (!$room) {
            $stmtFallback = $this->db->query("
                SELECT unit_id, room_number, building 
                FROM apartment_units 
                WHERE status = 'Available' 
                ORDER BY unit_id ASC 
                LIMIT 1
            ");
            $room = $stmtFallback->fetch(PDO::FETCH_ASSOC);
        }

        if ($room) {
            // ── ASSIGN: Room is available ──
            $this->db->prepare("
                UPDATE apartment_units SET status = 'Occupied', tenant_id = :tid, application_id = :aid 
                WHERE unit_id = :uid
            ")->execute([
                'tid' => $app['tenant_id'],
                'aid' => $applicationId,
                'uid' => $room['unit_id']
            ]);

            // Update application
            $this->db->prepare("
                UPDATE apartmentsapp 
                SET status = 'Assigned', unit_id = :uid, assigned_at = NOW(), accepted_at = NOW()
                WHERE application_id = :aid
            ")->execute(['uid' => $room['unit_id'], 'aid' => $applicationId]);

            // Change role: Guest → Tenant
            $this->changeRoleToTenant((int) $app['tenant_id']);

            return [
                'result' => 'assigned',
                'unit_id' => $room['unit_id'],
                'room_number' => $room['room_number'],
                'building' => $room['building']
            ];
        } else {
            // ── QUEUE: No rooms available ──
            $qStmt = $this->db->prepare("SELECT COALESCE(MAX(queue_position), 0) + 1 FROM apartmentsapp WHERE status = 'Queued'");
            $qStmt->execute();
            $nextPos = (int) $qStmt->fetchColumn();

            $this->db->prepare("
                UPDATE apartmentsapp 
                SET status = 'Queued', queue_position = :pos, accepted_at = NOW()
                WHERE application_id = :aid
            ")->execute(['pos' => $nextPos, 'aid' => $applicationId]);

            return [
                'result' => 'queued',
                'unit_id' => null,
                'room_number' => null,
                'building' => null,
                'queue_position' => $nextPos,
                'message' => 'No rooms available. You have been placed in the queue.'
            ];
        }
    }

    /**
     * Assign room alias for backward compatibility.
     */
    public function assignRoom(int $applicationId): array
    {
        return $this->assignOrQueue($applicationId);
    }

    /**
     * When a tenant moves out (room becomes Available), 
     * check if there's anyone queued for that room type and auto-assign.
     */
    public function releaseRoom(int $unitId): array
    {
        // Get unit info
        $stmt = $this->db->prepare("
            SELECT u.*, t.label AS type_label 
            FROM apartment_units u 
            JOIN apartment_types t ON u.type_id = t.type_id 
            WHERE u.unit_id = :uid
        ");
        $stmt->execute(['uid' => $unitId]);
        $unit = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$unit) return ['result' => 'error', 'message' => 'Unit not found'];

        // Reset the unit to Available
        $this->db->prepare("
            UPDATE apartment_units 
            SET status = 'Available', tenant_id = NULL, application_id = NULL 
            WHERE unit_id = :uid
        ")->execute(['uid' => $unitId]);

        // Check if anyone is queued for this type
        $stmt = $this->db->prepare("
            SELECT application_id, tenant_id 
            FROM apartmentsapp 
            WHERE (TRIM(roomtype) = TRIM(:rt) OR roomtype LIKE :rt_like) AND status = 'Queued' 
            ORDER BY queue_position ASC 
            LIMIT 1
        ");
        $stmt->execute(['rt' => $unit['type_label'], 'rt_like' => '%' . trim($unit['type_label']) . '%']);
        $next = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($next) {
            // Auto-assign to next in queue
            return $this->assignOrQueue((int)$next['application_id']);
        }

        return ['result' => 'released', 'message' => 'Room released. No one in queue.'];
    }

    /**
     * Get the waitlist for a specific room type.
     */
    public function getWaitlist(?string $roomtype = null): array
    {
        $sql = "
            SELECT a.*, u.first_name, u.last_name
            FROM apartmentsapp a
            JOIN tenant_accounts u ON a.tenant_id = u.tenant_id
            WHERE a.status = 'Queued'
        ";
        $params = [];
        if ($roomtype) {
            $sql .= " AND a.roomtype = :rt";
            $params['rt'] = $roomtype;
        }
        $sql .= " ORDER BY a.queue_position ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get queue position for a specific application.
     */
    public function getQueuePosition(int $applicationId): ?int
    {
        $stmt = $this->db->prepare("SELECT queue_position FROM apartmentsapp WHERE application_id = :id AND status = 'Queued'");
        $stmt->execute(['id' => $applicationId]);
        $pos = $stmt->fetchColumn();
        return $pos !== false ? (int) $pos : null;
    }

    /**
     * Get the assigned room details for a tenant.
     */
    public function getAssignedRoom(int $tenantId): ?array
    {
        $stmt = $this->db->prepare("
            SELECT u.*, t.label AS type_label, t.price, t.type_key, a.assigned_at
            FROM apartmentsapp a
            JOIN apartment_units u ON a.unit_id = u.unit_id
            JOIN apartment_types t ON u.type_id = t.type_id
            WHERE a.tenant_id = :tid AND a.status = 'Assigned'
            ORDER BY a.assigned_at DESC LIMIT 1
        ");
        $stmt->execute(['tid' => $tenantId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    // ── Helper: Map room type label to type_id ──
    public function getTypeIdByLabel(string $label): ?int
    {
        $trimmed = trim($label);
        $stmt = $this->db->prepare("
            SELECT type_id FROM apartment_types 
            WHERE label LIKE :lbl OR type_key = :key OR TRIM(label) = :trimmed
            LIMIT 1
        ");
        $stmt->execute(['lbl' => '%' . $trimmed . '%', 'key' => $trimmed, 'trimmed' => $trimmed]);
        $id = $stmt->fetchColumn();
        return $id ? (int) $id : null;
    }

    // ── Helper: Change role from Guest to Tenant ──
    public function changeRoleToTenant(int $tenantId): bool
    {
        $stmt = $this->db->prepare("UPDATE tenant_accounts SET role = 'Tenant' WHERE tenant_id = :tid AND (role = 'Guest' OR role = 'Applicant')");
        $ok = $stmt->execute(['tid' => $tenantId]);
        if (isset($_SESSION['user_id']) && (int)$_SESSION['user_id'] === $tenantId) {
            $_SESSION['role'] = 'Tenant';
        }
        return $ok;
    }

}
